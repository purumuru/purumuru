## Open Smartthings IDE.<br/>

#### Click New Smartapp<br/>
![create](../../../imgs/smartapp/create.png) 

#### Click From Code tab<br/>
![create](../../../imgs/smartapp/create2.png) 

#### Paste code<br/>
![create](../../../imgs/smartapp/create3.png) 

#### Click Edit Properties<br/>
![create](../../../imgs/smartapp/update1.png) 

#### Click Enable OAuth<br/>
![create](../../../imgs/smartapp/update2.png) 

<br/><br/>

## Open Smartthings App.<br/>

#### Click Automation Tab and click Add a SmartApp<br/>
![create](../../../imgs/smartapp/app-add1.jpg) 

#### Click My Smartapp<br/>
![create](../../../imgs/smartapp/app-add2.jpg) 

#### Select Mi Connector<br/>
![create](../../../imgs/smartapp/app-add3.jpg) 

#### Fill the blank with local address and Click the save button<br/>
Be careful. The address is not external ip.<br/>
![create](../../../imgs/smartapp/app-add4.jpg) 
