
<img src="./xiaomi_weather_graph_temperature.png?raw=true" >
<img src="./xiaomi_weather_graph_humidity.png?raw=true">
<img src="./xiaomi_weather_graph_temperature_total.png?raw=true" >
<img src="./xiaomi_weather_graph_temperature_total2.png?raw=true">

<img src="./mi_connector_graph1.png?raw=true">
<img src="./web-graph.png?raw=true">
<img src="./mi_connector_graph3.png?raw=true">
<img src="./mi_connector_graph4.png?raw=true">
<img src="./mi_connector_graph5.png?raw=true">
<img src="./mi_connector_graph6.png?raw=true">
