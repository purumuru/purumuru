
## Xiaomi Air Monitor
<img src="./xiaomi-air-monitor.png" title="Button" width="400px">

## Xiaomi Fan
<img src="./xiaomi-fan.jpg" title="Button" width="400px">

## Xiaomi Air Purifier
<img src="./xiaomi-air-pirifier.jpg" title="Button" width="400px">

## Xiaomi Humidifier
<img src="./xiaomi-humidifier.jpg" title="Button" width="400px">

## Xiaomi Light Mono
<img src="./xiaomi-light-mono.jpg" title="Button" width="400px">

## Xiaomi Light
<img src="./xiaomi-light.jpg" title="Button" width="400px">
